You've just downloaded a brush set FOR PHOTOSHOP CS2. An imagepack is included for other versions/programs.

Please keep the following in mind if you decide to use these:

1. Do not redistribute or claim as your own.
2. It would be muchly appreciated if you could link back to my DeviantART account if you decide to use these: http://bombay101.deviantart.com/
3. These were made from scratch by me, so please do not use them for commercial projects. Contact me (e-mail below) to inquire.
4. Most importantly, enjoy!

Feel free to contact me (bombay101@gmail.com) if you have any other questions, concerns, or would like to share what you've made using these.

Thanks for downloading!

- Jess

LiveJournal: Personal - http://regen.livejournal.com/ | Graphic Community - http://community.livejournal.com/apparating/
DeviantART: http://bombay101.deviantart.com/